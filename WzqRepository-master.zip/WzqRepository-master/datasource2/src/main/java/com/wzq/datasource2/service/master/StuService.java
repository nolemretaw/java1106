package com.wzq.datasource2.service.master;

import com.wzq.datasource2.entity.master.Stu;

import java.util.List;

public interface StuService {

    List<Stu> getAllStu();

}
