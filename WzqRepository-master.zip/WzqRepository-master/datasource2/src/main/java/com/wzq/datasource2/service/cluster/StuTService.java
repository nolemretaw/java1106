package com.wzq.datasource2.service.cluster;

import com.wzq.datasource2.entity.cluster.StuT;

import java.util.List;

public interface StuTService {

    List<StuT> getAllStuT();
}
