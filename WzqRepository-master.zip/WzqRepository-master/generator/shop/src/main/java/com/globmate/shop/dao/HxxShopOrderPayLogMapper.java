package com.globmate.shop.dao;

import com.globmate.shop.entity.HxxShopOrderPayLog;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author virus_plus
 * @since 2019-06-03
 */
public interface HxxShopOrderPayLogMapper extends BaseMapper<HxxShopOrderPayLog> {

}
